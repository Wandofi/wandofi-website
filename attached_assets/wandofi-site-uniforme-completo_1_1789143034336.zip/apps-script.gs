/**
 * WANDOFI PM · Receptor do teste de diagnostico
 * ---------------------------------------------------------------
 * Escreve cada resposta numa linha da folha e, se quiser, manda
 * um aviso por email. Nao usa servicos de terceiros: corre dentro
 * do seu Google Drive.
 *
 * COMO INSTALAR, PASSO A PASSO
 * ---------------------------------------------------------------
 *  1. Carregue o ficheiro wandofi-diagnosticos.xlsx para o Drive e
 *     abra-o com Google Sheets (botao direito > Abrir com >
 *     Google Sheets). Ja vem com os cabecalhos, o separador
 *     Resumo e a Legenda. Apague a linha amarela de exemplo.
 *     Em alternativa, crie uma folha vazia: o script cria os
 *     cabecalhos sozinho na primeira submissao.
 *  2. Nessa folha: Extensoes > Apps Script.
 *  3. Apague o que la estiver e cole este ficheiro inteiro.
 *  4. Na linha AVISO_PARA, confirme o seu email.
 *  5. Guarde (icone do disco).
 *  6. Implantar > Nova implantacao.
 *       Tipo:                 Aplicacao Web
 *       Descricao:            Diagnostico Wandofi v1
 *       Executar como:        Eu
 *       Quem tem acesso:      Qualquer pessoa            <-- IMPORTANTE
 *     Carregue em Implantar e autorize quando pedir.
 *     (Na autorizacao vai aparecer "Google nao verificou esta app".
 *      Carregue em Avancadas > Aceder a ... Isto acontece porque o
 *      script e seu e nao esta publicado na loja. E normal.)
 *  7. Copie o URL da aplicacao web. Tem este aspecto:
 *       https://script.google.com/macros/s/AKfy.../exec
 *  8. Abra diagnostico/index.html, procure URL_FOLHA e cole o URL
 *     entre as aspas.
 *  9. Teste: abra /diagnostico/, complete o teste, submeta, e
 *     confirme que apareceu uma linha nova na folha.
 *
 * SEMPRE QUE ALTERAR ESTE SCRIPT, tem de fazer
 * Implantar > Gerir implantacoes > editar (lapis) > Versao: Nova
 * > Implantar. Caso contrario o site continua a chamar a versao
 * antiga. E o erro mais comum.
 * ---------------------------------------------------------------
 */

/* ====== CONFIGURACAO ====== */

var AVISO_POR_EMAIL = true;              // false desliga o email
var AVISO_PARA      = "geral@wandofi.pt";
var NOME_DA_FOLHA   = "Diagnosticos";

/* ====== FIM DA CONFIGURACAO ====== */


/* Tem de bater certo, na ordem, com a folha wandofi-diagnosticos.xlsx.
   So sao usados se a folha estiver vazia; se ja tiver cabecalhos, o
   script limita-se a acrescentar linhas por baixo. */
var CABECALHOS = [
  "Data", "Nome", "Email", "Site",
  "Serviços", "Situação", "Dimensão", "Âmbito", "Medição", "Prazo desejado",
  "Estimativa mín", "Estimativa máx", "Semanas",
  "Origem", "Página"
];

function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(25000);
  } catch (err) {
    return resposta({ ok: false, erro: "ocupado" });
  }

  try {
    var d = JSON.parse(e.postData.contents);

    // Higiene minima: sem email valido nao vale a pena guardar.
    var email = String(d.email || "").trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      return resposta({ ok: false, erro: "email invalido" });
    }

    var folha = obtemFolha();
    folha.appendRow([
      new Date(),
      corta(d.nome, 120),
      corta(email, 160),
      corta(d.site, 200),
      corta(d.servicos, 200),
      corta(d.situacao, 40),
      corta(d.dimensao, 40),
      corta(d.ambito, 40),
      corta(d.medicao, 40),
      corta(d.prazo_desejado, 40),
      Number(d.estimativa_min) || "",
      Number(d.estimativa_max) || "",
      Number(d.semanas) || "",
      corta(d.origem, 300),
      corta(d.pagina, 300)
    ]);

    if (AVISO_POR_EMAIL) avisa(d, email);

    return resposta({ ok: true });

  } catch (err) {
    // Nao devolve o detalhe do erro ao site, so regista no log.
    console.error(err);
    return resposta({ ok: false, erro: "falhou" });
  } finally {
    lock.releaseLock();
  }
}

/** O GET serve so para confirmar que a implantacao esta viva. */
function doGet() {
  return resposta({ ok: true, servico: "Wandofi diagnostico" });
}

function obtemFolha() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var folha = ss.getSheetByName(NOME_DA_FOLHA);
  if (!folha) {
    folha = ss.insertSheet(NOME_DA_FOLHA);
  }
  if (folha.getLastRow() === 0) {
    folha.appendRow(CABECALHOS);
    folha.getRange(1, 1, 1, CABECALHOS.length).setFontWeight("bold");
    folha.setFrozenRows(1);
  }
  return folha;
}

function avisa(d, email) {
  var assunto = "Diagnostico novo: " + (d.nome || email);
  var linhas = [
    "Nome: " + (d.nome || ""),
    "Email: " + email,
    "Site: " + (d.site || "sem site"),
    "",
    "Servicos: " + (d.servicos || ""),
    "Situacao: " + (d.situacao || ""),
    "Dimensao: " + (d.dimensao || ""),
    "Ambito: " + (d.ambito || ""),
    "Medicao: " + (d.medicao || ""),
    "Prazo desejado: " + (d.prazo_desejado || ""),
    "",
    "Estimativa que viu: " + d.estimativa_min + " a " + d.estimativa_max + " euros",
    "Prazo mostrado: " + d.semanas + " semanas",
    "",
    "Origem: " + (d.origem || ""),
    "Pagina: " + (d.pagina || "")
  ];
  MailApp.sendEmail(AVISO_PARA, assunto, linhas.join("\n"));
}

function corta(v, n) {
  return String(v == null ? "" : v).slice(0, n);
}

function resposta(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Correr uma vez a mao, a partir do editor, para confirmar que
 * escreve na folha sem depender do site. Escolha testeLocal na
 * lista de funcoes e carregue em Executar.
 */
function testeLocal() {
  var falso = {
    postData: {
      contents: JSON.stringify({
        nome: "Teste", email: "teste@exemplo.pt", site: "exemplo.pt",
        servicos: "seo, site", situacao: "invisivel", dimensao: "micro",
        ambito: "lisboa", medicao: "nenhuma", prazo_desejado: "mes",
        estimativa_min: 1000, estimativa_max: 3000, semanas: 12,
        origem: "teste manual", pagina: "editor"
      })
    }
  };
  Logger.log(doPost(falso).getContent());
}
