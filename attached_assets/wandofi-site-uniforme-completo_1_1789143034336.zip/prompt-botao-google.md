# Prompt: botão "Fonte preferida no Google"

Para colar noutra conversa de IA, no Replit, ou dar a quem mexer no site.
Serve para qualquer página, deste site ou de um cliente.

---

## O prompt

```
Acrescenta a esta página um bloco com o botão de Fonte Preferida do Google.

CONTEXTO
A Google deixa cada utilizador escolher sites que quer ver primeiro nos
resultados, sobretudo nas notícias em destaque e nas respostas de IA da
Pesquisa. Existe globalmente desde o final de Abril de 2026, Portugal
incluído. Adiciona-se com um único link, e a Google permite expressamente
que o site faça o seu próprio botão.

O LINK
https://www.google.com/preferences/source?q=DOMINIO

Substitui DOMINIO pelo domínio, sem https:// e sem www.
Exemplo: https://www.google.com/preferences/source?q=wandofi.pt

ONDE COLOCAR
Regra: um pedido, uma acção. O botão nunca fica ao lado de outro CTA.
- Num artigo: logo a seguir ao fim do corpo do texto, antes das perguntas
  frequentes. É o momento de maior envolvimento.
- Numa página de serviço ou institucional: depois do CTA principal de
  contacto, nunca antes. Numa página que vende, o pedido de negócio vem
  primeiro.
- Num índice de blog: a seguir à lista de artigos publicados.
- Nunca no rodapé, nunca em pop-up, nunca em barra lateral.

MARCAÇÃO
<section class="section section--prefsrc">
  <div class="container">
    <div class="prefsrc">
      <div class="prefsrc__copy">
        <p class="prefsrc__label">Fonte preferida no Google</p>
        <p class="prefsrc__pitch">
          Se acompanha o que escrevo sobre TEMA, pode pedir ao Google para
          dar prioridade a NOME DO SITE nos seus resultados, nas notícias em
          destaque e nas respostas de IA da Pesquisa.
        </p>
      </div>
      <div class="prefsrc__action">
        <a class="btn btn--ghost"
           href="https://www.google.com/preferences/source?q=DOMINIO"
           target="_blank" rel="noopener">
          Tornar NOME DO SITE fonte preferida
          <span class="arrow" aria-hidden="true">&#8599;</span>
        </a>
        <p class="prefsrc__note">
          Abre as definições do Google numa nova janela. A escolha fica
          guardada na conta Google de quem carrega e não dá acesso a dados
          dessa pessoa.
        </p>
      </div>
    </div>
  </div>
</section>

ESTILO
Grelha de duas colunas: texto à esquerda, botão e nota à direita, com a
coluna da direita a 22rem. Empilha numa coluna abaixo de 860px. Caixa com
borda fina, filete vermelho de 2px à esquerda, cantos a 8px. A etiqueta em
maiúsculas pequenas na cor de acento. A nota em texto pequeno e discreto.
Usa as variáveis de cor e tipografia que a página já tiver, em vez de
inventar novas.

MEDIÇÃO
Se a página tiver GA4, acrescenta um ouvinte de cliques que dispare o
evento fonte_preferida quando alguém carregar num link que contenha
preferences/source. Põe esse código fora de qualquer bloco que dependa de
prefers-reduced-motion, para a medição correr sempre.

REGRAS DE TEXTO
- Português europeu, pré-acordo ortográfico.
- Sem travessões e sem hífenes de clítico (nada de "tira-lhe", "fazê-lo").
- Sem pontos de exclamação.

O QUE NÃO ESCREVER
Anda muita informação inventada sobre esta funcionalidade. Não afirmes que
duplica ou triplica o CTR, não digas que "salta o algoritmo" nem que
garante primeira página, e não cites números de utilizadores do AI Mode.
Nada disso tem fonte fiável. O único número publicado pela Google é que,
nos testes, mais de metade dos utilizadores que experimentaram escolheram
quatro ou mais fontes.

VERIFICAR NO FIM
1. O link abre as definições da Google e mostra o nome do site, não uma
   pesquisa vazia.
2. O botão não fica ao lado de outro CTA.
3. target="_blank" tem sempre rel="noopener".
4. Em telemóvel o botão ocupa a largura toda e não tapa nada.
```

---

## Notas de uso

**Para outra página do wandofi.pt.** O CSS do bloco já está embutido em
todas as páginas convertidas, por isso basta colar a marcação. As classes
`prefsrc`, `prefsrc__copy`, `prefsrc__action`, `btn btn--ghost` e
`section--prefsrc` já existem.

**Para o site de um cliente.** O prompt inclui a descrição do estilo, para
quem o receber conseguir escrever o CSS de raiz a condizer com o tema
dessa página.

**Sobre o CSS externo.** Em sites com build próprio, um ficheiro CSS novo
pode não ser servido. Se isso acontecer, o CSS vai embutido num `<style>`
dentro do `<head>` da própria página, e verifica-se no site publicado, não
na pré-visualização.
