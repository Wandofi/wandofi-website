/**
 * WANDOFI PM · Calibrador de precos, dentro da folha
 * ---------------------------------------------------------------
 * Cria (ou refaz) o separador "Calibrador" na mesma folha onde ja
 * esta o receptor do teste.
 *
 * COMO USAR
 *   1. Na folha: Extensoes > Apps Script.
 *   2. No editor, no painel da esquerda, carregue no + ao lado de
 *      "Ficheiros" e escolha Script. Chame-lhe calibrador.
 *   3. Cole este ficheiro inteiro. Guarde.
 *   4. Na lista de funcoes, escolha criarCalibrador e carregue em
 *      Executar. Autorize quando pedir.
 *   5. Volte a folha. O separador Calibrador esta la.
 *
 * O que fazer depois: so as celulas amarelas se editam. Tudo o que
 * esta a preto calcula-se sozinho. Quando os numeros estiverem bons,
 * copie a coluna do bloco final e cole no index.html do diagnostico,
 * por cima do var CONFIG que la esta.
 *
 * Correr outra vez apaga o separador e refa-lo com os valores de
 * origem. Se ja tiver afinado precos, NAO corra outra vez.
 *
 * NOTA SOBRE O SEPARADOR DAS FORMULAS
 * Numa folha em portugues, a virgula e o separador decimal, e os
 * argumentos das funcoes separam-se com ponto e virgula. Uma
 * formula escrita com virgulas da #ERROR! nessa folha. Este script
 * descobre sozinho qual e o separador certo, escrevendo =SUM(1,1)
 * numa celula de teste e vendo se resulta. Por isso funciona em
 * qualquer idioma sem ser preciso configurar nada.
 * ---------------------------------------------------------------
 */

var CAL_NOME = "Calibrador";

/* Valores de arranque. Sao os que estao agora no site. */
var CAL_SERVICOS = [
  ["SEO técnico e conteúdo",   "seo",        450,  1500, 12],
  ["Site novo",                "site",       600,  3000, 6],
  ["Migração de site",         "migracao",   500,  1300, 4],
  ["Automações e integrações", "automacao",  600,  2000, 6],
  ["Estrutura e burocracia",   "estrutura",  450,  1200, 4],
  ["Plataforma ou LMS",        "plataforma", 1500, 6000, 10]
];
var CAL_DIMENSAO = [
  ["ENI ou profissional liberal", "eni",     1.00],
  ["1 a 5 pessoas",               "micro",   1.15],
  ["6 a 15 pessoas",              "pequena", 1.50],
  ["Mais de 15 pessoas",          "media",   1.80]
];
var CAL_AMBITO = [
  ["Um concelho",      "local",    1.00],
  ["Grande Lisboa",    "lisboa",   1.10],
  ["Todo o país",      "nacional", 1.25],
  ["Fora de Portugal", "interna",  1.60]
];
var CAL_REGRAS = [
  ["Medição: acréscimo mínimo",  150],
  ["Medição: acréscimo máximo",  400],
  ["Medição: semanas a somar",   2],
  ["Arredondar a múltiplos de",  50]
];

/* Linhas onde cada coisa fica. Mudar isto parte as formulas. */
var L_SERV = 5;    // 5 a 10
var L_DIM  = 13;   // 13 a 16
var L_AMB  = 19;   // 19 a 22
var L_REG  = 25;   // 25 a 28  (min, max, semanas, arredondar)

/* Os valores das regras vivem na coluna C, tal como os precos. */
var R_EXTRA_MIN = "$C$" + L_REG;
var R_EXTRA_MAX = "$C$" + (L_REG + 1);
var R_EXTRA_SEM = "$C$" + (L_REG + 2);
var R_ARRED     = "$C$" + (L_REG + 3);

/* Cenarios: linhas dos servicos, linha da dimensao, linha do ambito,
   e se o cliente NAO tem medicao montada. */
var CAL_CENARIOS = [
  ["Só aparecer no Google",          [0],           0, 0, true],
  ["SEO, 1 a 5 pessoas, Lisboa",     [0],           1, 1, true],
  ["Só um site",                     [1],           0, 0, true],
  ["Só automação, já mede",          [3],           1, 0, false],
  ["Abrir negócio e automatizar",    [3, 4],        0, 0, true],
  ["Site novo e SEO, sozinho",       [0, 1],        0, 0, true],
  ["Site e SEO, 1 a 5, Lisboa",      [0, 1],        1, 1, true],
  ["Migrar e fazer SEO, já mede",    [2, 0],        1, 1, false],
  ["Pacote, 6 a 15, nacional",       [0, 1, 3],     2, 2, true],
  ["Escola online, 6 a 15",          [1, 5],        2, 2, true],
  ["Tudo, mais de 15, internacional",[0,1,2,3,4,5], 3, 3, true]
];

var INK = "#101010", MUTE = "#66625e", VERM = "#e1251b";
var AMARELO = "#fff2cc", CINZA = "#f2f2f2";

/* Separador de argumentos desta folha. Preenchido por descobreSeparador(). */
var SEP = ",";

/**
 * Escreve =SUM(1,1) numa celula de canto e ve o que sai.
 * Se der 2, a folha aceita virgulas. Se der erro, usa ponto e virgula.
 */
function descobreSeparador(s) {
  var teste = s.getRange("Z1");
  try {
    teste.setFormula("=SUM(1,1)");
    SpreadsheetApp.flush();
    SEP = (teste.getValue() === 2) ? "," : ";";
  } catch (e) {
    SEP = ";";
  }
  teste.clearContent();
  return SEP;
}

/** Junta argumentos com o separador certo desta folha. */
function arg() {
  return Array.prototype.slice.call(arguments).join(SEP);
}


function criarCalibrador() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var velho = ss.getSheetByName(CAL_NOME);
  if (velho) ss.deleteSheet(velho);
  var s = ss.insertSheet(CAL_NOME);

  descobreSeparador(s);

  s.setHiddenGridlines(true);
  var larguras = [30, 260, 90, 90, 90, 90, 30, 250, 95, 95, 95, 95, 90, 30, 520];
  for (var i = 0; i < larguras.length; i++) s.setColumnWidth(i + 1, larguras[i]);

  /* ---------- titulo ---------- */
  s.getRange("B1").setValue("Calibrador de preços")
    .setFontFamily("Arial").setFontSize(16).setFontWeight("bold").setFontColor(INK);
  s.getRange("B2").setValue(
    "Só as células amarelas se editam. O resto calcula-se sozinho. "
    + "No fim, copie a coluna O e cole no index.html do diagnóstico.")
    .setFontFamily("Arial").setFontSize(10).setFontColor(MUTE);

  /* ---------- entradas: servicos ---------- */
  cabecalho(s, "B4:F4", ["Serviço", "Mín €", "Máx €", "Semanas", "Amplitude"]);
  for (var i = 0; i < CAL_SERVICOS.length; i++) {
    var r = L_SERV + i, d = CAL_SERVICOS[i];
    s.getRange(r, 2).setValue(d[0]);
    s.getRange(r, 3).setValue(d[2]);
    s.getRange(r, 4).setValue(d[3]);
    s.getRange(r, 5).setValue(d[4]);
    s.getRange(r, 6).setFormula("=IFERROR(" + arg("D" + r + "/C" + r, "0") + ")");
  }
  entrada(s, s.getRange(L_SERV, 3, CAL_SERVICOS.length, 3));
  s.getRange(L_SERV, 3, CAL_SERVICOS.length, 2).setNumberFormat('#,##0 "€"');
  s.getRange(L_SERV, 6, CAL_SERVICOS.length, 1).setNumberFormat('0.0"×"');

  /* ---------- entradas: multiplicadores ---------- */
  bloco(s, 12, "Dimensão do negócio", CAL_DIMENSAO, L_DIM);
  bloco(s, 18, "Alcance geográfico",  CAL_AMBITO,  L_AMB);

  /* ---------- entradas: regras ---------- */
  s.getRange(24, 2).setValue("Regras").setFontWeight("bold").setFontColor(INK);
  s.getRange(24, 2, 1, 2).setBackground(CINZA);
  for (var i = 0; i < CAL_REGRAS.length; i++) {
    s.getRange(L_REG + i, 2).setValue(CAL_REGRAS[i][0]);
    s.getRange(L_REG + i, 3).setValue(CAL_REGRAS[i][1]);
  }
  entrada(s, s.getRange(L_REG, 3, CAL_REGRAS.length, 1));
  s.getRange(29, 2).setValue("O arredondamento tem de ser maior do que zero.")
    .setFontSize(9).setFontColor(MUTE);

  /* ---------- saida: uma frente de cada vez ---------- */
  s.getRange("H4").setValue("Uma frente de cada vez · cliente individual · um concelho")
    .setFontWeight("bold").setFontColor(INK);
  cabecalho(s, "H5:M5", ["Serviço", "Mín", "Máx", "Mín sem medição", "Máx sem medição", "Semanas"]);
  var multBase = "$C$" + L_DIM + "*$C$" + L_AMB;
  for (var i = 0; i < CAL_SERVICOS.length; i++) {
    var rs = L_SERV + i, r = 6 + i;
    s.getRange(r, 8).setFormula("=B" + rs);
    s.getRange(r, 9).setFormula(arred("C" + rs + "*" + multBase));
    s.getRange(r,10).setFormula(arred("D" + rs + "*" + multBase));
    s.getRange(r,11).setFormula(arred("(C" + rs + "+" + R_EXTRA_MIN + ")*" + multBase));
    s.getRange(r,12).setFormula(arred("(D" + rs + "+" + R_EXTRA_MAX + ")*" + multBase));
    s.getRange(r,13).setFormula("=E" + rs + "+" + R_EXTRA_SEM);
  }
  s.getRange(6, 9, CAL_SERVICOS.length, 4).setNumberFormat('#,##0 "€"');

  /* ---------- saida: cenarios ---------- */
  s.getRange("H14").setValue("Os pedidos que vão mesmo aparecer")
    .setFontWeight("bold").setFontColor(INK);
  cabecalho(s, "H15:M15", ["Cenário", "Mín", "Máx", "Amplitude", "Semanas", ""]);
  for (var i = 0; i < CAL_CENARIOS.length; i++) {
    var c = CAL_CENARIOS[i], r = 16 + i;
    var somaMin = [], somaMax = [], semanas = [];
    for (var k = 0; k < c[1].length; k++) {
      var rs = L_SERV + c[1][k];
      somaMin.push("C" + rs); somaMax.push("D" + rs); semanas.push("E" + rs);
    }
    var m = "$C$" + (L_DIM + c[2]) + "*$C$" + (L_AMB + c[3]);
    var extraMin = c[4] ? "+" + R_EXTRA_MIN : "";
    var extraMax = c[4] ? "+" + R_EXTRA_MAX : "";
    var extraSem = c[4] ? "+" + R_EXTRA_SEM : "";
    var maisDeDois = c[1].length > 2 ? "+2" : "";

    s.getRange(r, 8).setValue(c[0]);
    s.getRange(r, 9).setFormula(arred("(SUM(" + somaMin.join(SEP) + ")" + extraMin + ")*" + m));
    s.getRange(r,10).setFormula(arred("(SUM(" + somaMax.join(SEP) + ")" + extraMax + ")*" + m));
    s.getRange(r,11).setFormula("=IFERROR(" + arg("J" + r + "/I" + r, "0") + ")");
    s.getRange(r,12).setFormula("=MAX(" + semanas.join(SEP) + ")" + extraSem + maisDeDois);
  }
  var nC = CAL_CENARIOS.length;
  s.getRange(16, 9, nC, 2).setNumberFormat('#,##0 "€"');
  s.getRange(16,11, nC, 1).setNumberFormat('0.0"×"');
  s.getRange(16 + nC - 1, 8, 1, 5).setFontColor(MUTE).setFontStyle("italic");

  /* ---------- mostradores ---------- */
  var rm = 16 + nC + 1;
  s.getRange(rm, 8).setValue("Chão e tecto").setFontWeight("bold").setFontColor(INK);
  var pares = [
    ["Número mais baixo que alguém pode ver", "=MIN(I6:I" + (5 + CAL_SERVICOS.length) + ")", '#,##0 "€"'],
    ["Número mais alto que alguém pode ver",  "=J" + (16 + nC - 1),                          '#,##0 "€"'],
    ["Amplitude mais larga da tabela",        "=MAX(F" + L_SERV + ":F" + (L_SERV + 5) + ")", '0.0"×"']
  ];
  for (var i = 0; i < pares.length; i++) {
    s.getRange(rm + 1 + i, 8).setValue(pares[i][0]);
    s.getRange(rm + 1 + i, 9).setFormula(pares[i][1])
      .setNumberFormat(pares[i][2]).setFontWeight("bold");
  }
  s.getRange(rm + 5, 8).setValue(
    "Amplitude é o máximo a dividir pelo mínimo. Acima de 3,5× a faixa "
    + "começa a soar a quem não sabe o que cobra.")
    .setFontSize(9).setFontColor(MUTE);

  /* ---------- bloco para colar ---------- */
  s.getRange("O4").setValue("Bloco para colar no index.html do diagnóstico")
    .setFontWeight("bold").setFontColor(INK);
  var linhas = linhasConfig();
  for (var i = 0; i < linhas.length; i++) {
    var cel = s.getRange(5 + i, 15);
    if (linhas[i].charAt(0) === "=") cel.setFormula(linhas[i]); else cel.setValue(linhas[i]);
    cel.setFontFamily("Courier New").setFontSize(9).setFontColor(INK);
  }
  s.getRange(5 + linhas.length + 1, 15).setValue(
    "Copie da linha 5 até aqui em cima, cole num editor de texto e "
    + "substitua o bloco var CONFIG que está no index.html.")
    .setFontFamily("Arial").setFontSize(9).setFontColor(MUTE).setWrap(true);

  /* ---------- cor na amplitude ---------- */
  var alvos = [
    s.getRange(L_SERV, 6, CAL_SERVICOS.length, 1),
    s.getRange(16, 11, nC, 1)
  ];
  var regras = [
    SpreadsheetApp.newConditionalFormatRule().whenNumberGreaterThan(3.5)
      .setFontColor(VERM).setRanges(alvos).build(),
    SpreadsheetApp.newConditionalFormatRule().whenNumberBetween(2.5, 3.5)
      .setFontColor("#9a6108").setRanges(alvos).build(),
    SpreadsheetApp.newConditionalFormatRule().whenNumberLessThan(2.5)
      .setFontColor("#1c7049").setRanges(alvos).build()
  ];
  s.setConditionalFormatRules(regras);

  s.getRange("A1:O60").setFontFamily("Arial").setFontSize(10);
  s.getRange("B1").setFontSize(16).setFontWeight("bold");
  s.getRange(5, 15, linhas.length, 1).setFontFamily("Courier New").setFontSize(9);
  s.setFrozenRows(2);
  ss.setActiveSheet(s);
  try {
    SpreadsheetApp.getUi().alert(
      "Calibrador criado.\n\nEdite só as células amarelas. "
      + "O bloco para colar no site está na coluna O.");
  } catch (e) {
    Logger.log("Calibrador criado.");
  }
}


/* ================= auxiliares ================= */

function arred(expr) {
  return "=IFERROR(MROUND(" + arg(expr, R_ARRED) + ")" + SEP + "0)";
}

function cabecalho(s, a1, titulos) {
  var r = s.getRange(a1);
  r.setValues([titulos]).setFontWeight("bold").setFontSize(9)
   .setFontColor("#ffffff").setBackground(INK).setWrap(true);
}

function entrada(s, r) {
  r.setBackground(AMARELO).setFontColor("#0000ff").setFontWeight("bold");
}

function bloco(s, linhaTitulo, titulo, dados, linhaInicio) {
  s.getRange(linhaTitulo, 2).setValue(titulo).setFontWeight("bold").setFontColor(INK);
  s.getRange(linhaTitulo, 2, 1, 2).setBackground(CINZA);
  for (var i = 0; i < dados.length; i++) {
    s.getRange(linhaInicio + i, 2).setValue(dados[i][0]);
    s.getRange(linhaInicio + i, 3).setValue(dados[i][2]);
  }
  var r = s.getRange(linhaInicio, 3, dados.length, 1);
  entrada(s, r);
  r.setNumberFormat("0.00");
}

/**
 * Monta as linhas do bloco CONFIG. As que comecam por = sao formulas,
 * por isso acompanham os valores das celulas amarelas.
 *
 * Os inteiros (min, max, semanas) podem ser concatenados directamente.
 * Os multiplicadores NAO: numa folha em portugues, 1,15 concatenado
 * daria "1,15" e isso nao e JavaScript valido. Por isso a parte
 * inteira e as casas decimais sao montadas a mao, com um ponto
 * literal pelo meio.
 */
function decimalComPonto(ref) {
  var cem = "ROUND(" + ref + "*100)";
  var dec = "MOD(" + arg(cem, "100") + ")";
  return "INT(" + cem + "/100)&\".\"&IF(" + arg(dec + "<10", '"0"&' + dec, dec) + ")";
}

function linhasConfig() {
  function txt(s) { return '"' + s.replace(/"/g, '""') + '"'; }
  var L = [];
  L.push("var PRECOS_CONFIRMADOS = true;");
  L.push("");
  L.push("var CONFIG = {");
  L.push("  servicos: {");
  for (var i = 0; i < CAL_SERVICOS.length; i++) {
    var r = L_SERV + i, d = CAL_SERVICOS[i];
    L.push("=" + txt("    " + d[1] + ": { nome: \"" + d[0] + "\", min: ")
      + "&C" + r + "&" + txt(", max: ") + "&D" + r + "&" + txt(", semanas: ")
      + "&E" + r + "&" + txt(" },"));
  }
  L.push("  },");
  L.push("  dimensao: {");
  for (var i = 0; i < CAL_DIMENSAO.length; i++) {
    var r = L_DIM + i, d = CAL_DIMENSAO[i];
    L.push("=" + txt("    " + d[1] + ": { nome: \"" + d[0] + "\", mult: ")
      + "&" + decimalComPonto("C" + r) + "&" + txt(" },"));
  }
  L.push("  },");
  L.push("  ambito: {");
  for (var i = 0; i < CAL_AMBITO.length; i++) {
    var r = L_AMB + i, d = CAL_AMBITO[i];
    L.push("=" + txt("    " + d[1] + ": { nome: \"" + d[0] + "\", mult: ")
      + "&" + decimalComPonto("C" + r) + "&" + txt(" },"));
  }
  L.push("  },");
  L.push("=" + txt("  extraMedicao: { min: ") + "&C" + L_REG + "&" + txt(", max: ")
    + "&C" + (L_REG + 1) + "&" + txt(", semanas: ") + "&C" + (L_REG + 2) + "&" + txt(" },"));
  L.push("=" + txt("  arredondar: ") + "&C" + (L_REG + 3));
  L.push("};");
  return L;
}
